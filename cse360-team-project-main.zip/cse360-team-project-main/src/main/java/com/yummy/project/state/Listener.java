package com.yummy.project.state;

public interface Listener {
    public void onChanged();
}
